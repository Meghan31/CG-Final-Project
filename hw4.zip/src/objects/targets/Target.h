// Factory for the archery-style target (stand + rings board)
#pragma once
#include "../../rendering/mesh/Mesh.h"

Mesh createTarget();
