// Factory for the ground mesh (a big flat quad)
#pragma once
#include "../../rendering/mesh/Mesh.h"

Mesh createGround();
